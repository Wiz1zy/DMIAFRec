import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.init import xavier_uniform_, xavier_normal_
from src.BasicModel import build_noise,NCELoss
#from BasicModel import BasicModel
from ours_tools.Loss import BPRLoss
from info_nce import InfoNCE
import numpy as np
import pdb
from src.BasicModel import BasicModel, CapsuleNetwork
Len = {'rocket':5,'gowalla':20,'book':20}

# 超图卷积网络
class HyperConv(nn.Module):
    def __init__(self, layers):
        super(HyperConv, self).__init__()
        self.layers = layers
    def forward(self, adjacency, embedding):
        item_embeddings = embedding
        item_embedding_layer0 = item_embeddings
        final = [item_embedding_layer0]
        for i in range(self.layers):
            item_embeddings = torch.sparse.mm(adjacency, item_embeddings)
            final.append(item_embeddings)
        item_embeddings = torch.mean(torch.stack(final,dim=1), dim=1) / (self.layers+1)
        return item_embeddings

    
class Contrastive(nn.Module):

    def __init__(self, args,R_sp):
        super(Contrastive, self).__init__()
        self.hidden_size = args.hidden_size
        self.hgcn = args.hgcn # 是否超图卷积网络
        self.dropout = args.dropout
        self.item_num = args.n_item
        self.adj_torch = self.norm_adj(R_sp) if self.hgcn else 0
        self.time_decay = args.time_decay

        #self.dense = nn.Linear(self.hidden_size, self.n_cluster)
        self.emb_dropout = nn.Dropout(self.dropout)
        #self.ui_embeddings = nn.Embedding(self.user_num, self.emb_size)
        #self.iu_embeddings = nn.Embedding(self.item_num, self.emb_size)
        #self.li_embeddings = nn.Embedding(self.item_num, self.hidden_size, padding_idx=0)     
        self.embeddings = nn.Embedding(self.item_num, self.hidden_size, padding_idx=0)
        self.pos_embedding = nn.Embedding(self.seq_len, self.hidden_size)
        self.apply(self._init_weights)
        self.loss_func = BPRLoss()
        self.HyperGraph = HyperConv(2)
        self.interest_num = args.interest_num # 默认是5
        self.seq_len = Len[args.dataset]
        self.routing_times = 1
        
        self.capsule_network = CapsuleNetwork(self.hidden_size, self.seq_len, bilinear_type=0, interest_num=self.interest_num, 
                                            routing_times=self.routing_times, hard_readout=True, relu_layer=False)
        
        
        self.loss_contrastive = InfoNCE(negative_mode='paired') # negative_mode='unpaired' is the default value
        self.name ='Contrastive'

    # 每个元素表示节点之间的连接强度（权重）
    def norm_adj(self,R_sp):
        epsilon = 1e-10 
        H_T = R_sp
        BH_T = H_T.T.multiply((1.0 / (H_T.sum(axis=1) + epsilon).reshape([1,-1])))
        BH_T = BH_T.T
        H = H_T.T
        DH = H.T.multiply((1.0 / (H.sum(axis=1)+ epsilon).reshape([1,-1])))
        DH = DH.T
        DHBH_T = DH.dot(BH_T)
        # to devices
        values = DHBH_T.data
        indices = np.vstack(DHBH_T.nonzero())
        index_fliter = (values < 0.05).nonzero()
        values = np.delete(values, index_fliter)
        indices1 = np.delete(indices[0], index_fliter)
        indices2 = np.delete(indices[1], index_fliter)
        indices = [indices1, indices2]

        i = torch.LongTensor(indices)
        v = torch.FloatTensor(values)
        shape = DHBH_T.shape
        adjacency = torch.sparse.FloatTensor(i, v, torch.Size(shape)).cuda()
        #pdb.set_trace()

        return adjacency

    def _init_weights(self, module):
        if isinstance(module, nn.Embedding):
            xavier_normal_(module.weight)
        elif isinstance(module, nn.GRU):
            xavier_uniform_(module.weight_hh_l0)
            xavier_uniform_(module.weight_ih_l0)
    # def _init_weights(self, module):
    #     if isinstance(module, nn.Embedding):
    #         nn.init.xavier_normal_(module.weight)
    #     elif isinstance(module, nn.GRU):
    #         nn.init.orthogonal_(module.weight_hh_l0)
    #         nn.init.xavier_uniform_(module.weight_ih_l0)
    #         nn.init.constant_(module.bias_hh_l0, 1.0)
    #         nn.init.constant_(module.bias_ih_l0, 1.0)
    #     elif isinstance(module, nn.Linear):
    #         nn.init.kaiming_normal_(module.weight, nonlinearity='relu')
    #         if module.bias is not None:
    #             nn.init.constant_(module.bias, 0)
    #     elif isinstance(module, nn.LayerNorm):
    #         module.weight.data.fill_(1.0)
    #         module.bias.data.zero_()

    def forward(self, item_list, label_list, mask, device, train=True, times=None):
        # 对应 3.2 用户多兴趣学习模块
        item_embeddings = self.hgcn_embeddings()


        # 对应 3.2.1 项目嵌入层
        item_eb = item_embeddings[item_list]  # [batch, seq, d]
        batch_size, seq_len = item_list.shape
        pos_indices = torch.arange(seq_len, device=device).unsqueeze(0).expand(batch_size, seq_len)
        pos_eb = self.pos_embedding(pos_indices)  # 获取位置向量

        item_eb = item_eb + pos_eb  # 逐元素相加，融合顺序信息
        item_seq_emb_dropout = self.emb_dropout(item_eb)

        # 对应 3.2.2 多兴趣提取层
        user_eb, capsule_weight = self.capsule_network(item_seq_emb_dropout, mask, device)  # [none,multi-facet,d]   user_eb用户的兴趣胶囊的形状为 [batch_size, interest_num, hidden_size]
        capsule_weight = F.softmax(capsule_weight, dim=-1)  # 矩阵A，shape=(batch_size, num_heads, maxlen)

        # 对应 3.2.3 多兴趣注意力融合层
        # A. 计算时间间隔和个性化时间尺度 alpha
        intervals = times[:, 1:] - times[:, :-1]
        valid_intervals_mask = mask[:, 1:] * mask[:, :-1]
        intervals_float = intervals.float()
        intervals_float[valid_intervals_mask == 0] = float('nan')

        # 取中位数作为时间尺度估计值 mu_u
        mu_u = torch.nanmedian(intervals_float, dim=1).values
        mu_u = torch.nan_to_num(mu_u, nan=1.0)


        # B. 计算时间衰减权重
        valid_lens = mask.sum(dim=1).long()  # [batch] 获取每个样本的真实有效长度
        last_indices = valid_lens - 1  # [batch] 真实最后一个元素的索引

        t_now = times[torch.arange(batch_size, device=device), last_indices].unsqueeze(1)

        delta_t = t_now - times  # [batch, seq_len] (现在 delta_t 对有效时间来说必定 >= 0)
        exponent = -self.time_decay * (delta_t.float() / (mu_u.unsqueeze(1) + 1e-8))
        time_decay_weights = torch.exp(exponent)
        time_decay_weights = time_decay_weights * mask

        sum_w = torch.sum(time_decay_weights, dim=1, keepdim=True) + 1e-8
        # item_eb_mean: [batch, d]
        item_eb_mean = torch.sum(item_seq_emb_dropout * time_decay_weights.unsqueeze(-1), dim=1) / sum_w

        # C. 计算兴趣-用户注意力权重
        attn_scores = torch.bmm(user_eb, item_eb_mean.unsqueeze(2)).squeeze(2)  # [batch, interest_num]
        attn_weights = F.softmax(attn_scores, dim=1)  # 对兴趣维度做 softmax

        # D. 加权聚合得到最终用户偏好表示 (Readout)
        readout = torch.sum(user_eb * attn_weights.unsqueeze(-1), dim=1)  # [batch, d]

        # 计算得分用于后续预测
        scores = self.calculate_score(readout)

        return readout, scores, item_embeddings, capsule_weight, user_eb


    def set_device(self, device):
        self.device = device
    def calculate_score(self, user_eb):
        all_items = self.hgcn_embeddings()
        scores = torch.matmul(user_eb, all_items.transpose(1, 0)) # [b, n]
        return scores
    def hgcn_embeddings(self):
        item_embeddings_hg = self.HyperGraph(self.adj_torch, self.embeddings.weight) if self.hgcn else self.embeddings.weight
        return item_embeddings_hg#self.embeddings.weight
        
    def calculate_sampled_loss(self, readout, pos_item,neg_items,item_embeddings):
        pos_items_embs =  item_embeddings[pos_item]#self.normalize(self.embeddings(pos_item))#[none,d]
        neg_items_embs =  item_embeddings[neg_items]#self.normalize(self.embeddings(neg_items))#[none,d]
        pos_score = torch.sum(pos_items_embs * readout,dim=-1)#[none]
        neg_scores = torch.sum(neg_items_embs * readout.unsqueeze(1),dim=-1)#[none,maxlen]
        neg_score =  torch.max(neg_scores,dim=-1)[0]#[none]
        #print(neg_scores)
        return self.loss_func(pos_score,neg_score)

    def calculate_contrastive_loss(self,target,pos_item,neg_items,item_embeddings):
        item_embeddings = self.hgcn_embeddings()
        target_items_embs =  item_embeddings[target]#[none,d]
        pos_items_embs =   item_embeddings[pos_item]#[none,d]
        neg_items_embs =   item_embeddings[neg_items]#[none,d]
        
        
        return self.loss_contrastive(target_items_embs,pos_items_embs,neg_items_embs)
          
    def output_items(self):
        item_embeddings = self.hgcn_embeddings()
        return item_embeddings
    def calculate_atten_loss(self, attention):
        C_mean = torch.mean(attention, dim=2, keepdim=True)
        C_reg = (attention - C_mean)
        # C_reg = C_reg.matmul(C_reg.transpose(1,2)) / self.hidden_size
        C_reg = torch.bmm(C_reg, C_reg.transpose(1, 2)) / self.hidden_size
        dr = torch.diagonal(C_reg, dim1=-2, dim2=-1)
        n2 = torch.norm(dr, dim=(1)) ** 2
        return n2.sum()      
    def calculate_re4(self,item_list,mask, device, train=True):
        item_embeddings = self.hgcn_embeddings()
        dim0, dim1 = item_list.shape
        item_mask = (item_list == 0).reshape(dim0, -1)
        item_eb = item_embeddings[item_list]# [batch, seq, d]
        item_seq_emb_dropout = self.emb_dropout(item_eb)# [batch, seq, d]
        watch_interests,proposals_weight  = self.capsule_network(item_eb, mask, device)#[none,multi-facet,d]
        t_cont=0.02
        # re-contrast
        norm_watch_interests = F.normalize(watch_interests, p=2, dim=-1)
        norm_watch_movie_embedding = F.normalize(item_seq_emb_dropout, p=2, dim=-1)
        cos_sim = torch.matmul(norm_watch_interests, torch.transpose(norm_watch_movie_embedding, 1, 2))
        if True:
            gate = np.repeat(torch.FloatTensor([1/self.item_num]).repeat(dim0), self.seq_len,
                                 axis=0)
        gate = torch.reshape(gate, (dim0, 1, self.seq_len)).to(self.device)
        positive_weight_idx = (proposals_weight > gate) * 1  # value is 1 or 0
        mask_cos = cos_sim.masked_fill(item_mask.unsqueeze(1), -1e9)
        pos_cos = mask_cos.masked_fill(positive_weight_idx != 1, -1e9)
        import pdb
        cons_pos = torch.exp(pos_cos / t_cont)
        cons_neg = torch.sum(torch.exp(mask_cos / t_cont), dim=2)

        in2in = torch.matmul(norm_watch_interests, torch.transpose(norm_watch_interests, 1, 2))
        in2in = in2in.masked_fill(torch.eye(self.interest_num).to(in2in.device).unsqueeze(0) == 1, -1e9)
        cons_neg = cons_neg + torch.sum(torch.exp(in2in / t_cont), dim=2)

        item_rolled = torch.roll(norm_watch_movie_embedding, 1, 0)
        in2i = torch.matmul(norm_watch_interests, torch.transpose(item_rolled, 1, 2))
        in2i_mask = torch.roll((item_list == 0).reshape(dim0, dim1), 1, 0)
        in2i = in2i.masked_fill(in2i_mask.unsqueeze(1), -1e9)
        cons_neg = cons_neg + torch.sum(torch.exp(in2i / t_cont), dim=2)

        cons_div = cons_pos / cons_neg.unsqueeze(-1)
        cons_div = cons_div.masked_fill(item_mask.unsqueeze(1), 1)
        cons_div = cons_div.masked_fill(positive_weight_idx != 1, 1)
        # loss_contrastive = -torch.log(cons_pos / cons_neg.unsqueeze(-1))
        loss_contrastive = -torch.log(cons_div)
        loss_contrastive = torch.mean(loss_contrastive)
        return loss_contrastive
    
    