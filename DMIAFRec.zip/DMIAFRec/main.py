import scipy.sparse as sp
from scipy.sparse import csr_matrix
import os
import sys
from DMIAFRec import Contrastive
import time
import torch
from utils import get_parser, setup_seed
from evalution import test, output
from utils import get_DataLoader,TrainData, get_exp_name, get_model, load_model, save_model, to_tensor, load_item_cate, compute_diversity
from evalution import evaluate
from ours_tools.log import LOG
import pdb
from tqdm import tqdm
import numpy as np
neg_num={'book':50,'gowalla':10,'rocket':10,'gowalla6':10}
#filter_treshold = {'rocket':0.01,'gowalla':0.01,'book':0.001}

def get_matrix(train_data,n_user,n_item):
    graph_u = train_data.graph
    graph_i = dict()
    rows = []
    cols = []
    datas = []
    for u in graph_u: # 反向构建物品-用户图
        for i in graph_u[u]:
            if i in graph_i:
                graph_i[i].append(u)
            else:
                graph_i[i] = [u]
    for u in graph_u:
        for i in graph_u[u]:
            #if len(graph_u[u])>=5 and len(graph_i[i])>=5:
            rows.append(u) # 交互位置的行索引
            cols.append(i) # 列索引
            datas.append(1.0)
    R = csr_matrix((datas, (rows, cols)), shape=(n_user, n_item)) # 压缩稀疏行（CSR）格式的稀疏矩阵 R
    print("R complete, start to I-sp matrix")
    I_sp = R.T.dot(R) #物品之间的相似度矩阵，其中每个元素 I_sp[i, j] 表示物品 i 和物品 j 之间的相似度
    row_sums = np.array(I_sp.sum(axis=0)).flatten()+0.00001
    row_indices, col_indices = I_sp.nonzero()
    I_sp.data /= row_sums[row_indices] #对物品-物品相似度矩阵进行归一化
    I_sp = I_sp.T
    # 打印将对角元素设置为0后的稀疏矩阵
    I_sp.setdiag(0) #对角线元素设置为零
    # 将值小于0.01的去掉
    I_sp.data[I_sp.data < 0.01] = 0
    I_sp.eliminate_zeros()
    print("\n将对角元素设置为0后的稀疏矩阵:")
    #I = I_sp.toarray()
    #print(I_sp)
    return R, I_sp
def to_sample_graph(I_sp): #to_sample_graph 函数的主要作用是对稀疏矩阵 I_sp 进行标准化处理
    # 寻找具有最多元素的行
    max_elements_row = np.argmax(np.diff(I_sp.indptr))
    # 获取该行的元素数量
    max_n = np.diff(I_sp.indptr)[max_elements_row]
    values = []
    index = []
    for i in tqdm(range(I_sp.shape[0])):
        v = I_sp[i].data
        ind = I_sp[i].nonzero()[1]
        values.append(np.concatenate((v,np.zeros(max_n-len(v)))))
        index.append(np.concatenate((ind,np.zeros(max_n-len(v)))))
    values = np.array(values)
    index = np.array(index)
    return index,values #最终返回填充后的 index（列索引）和 values（非零值）


def get_arguments():
    args = dict()
    for arg in sys.argv[1:]:
        arg_name, arg_value = arg.split('=')
        try:
            arg_value = int(arg_value)
        except:
            try:
                arg_value = float(arg_value)
            except:
                pass
        arg_name = arg_name.strip('-')
        args[arg_name] = arg_value
    print(args)
    return args

def main_process(data_name,mode,contrastive_ratio,n_facets,ra_loss,time_decay):

    args = get_parser()
    args.random_seed = 3407
    SEED = args.random_seed
    setup_seed(SEED)
    args.ra_loss=ra_loss
    args.dataset = data_name
    args.time_decay = time_decay
    args.neg_sample = neg_num[data_name]
    args.contrastive_ratio = contrastive_ratio
    args.model_type = 'Contrastive'
    args.hgcn = False
    args.mode = mode
    args.interest_num = n_facets
    per_test = {'rocket':10,'gowalla':10,'book':1,'gowalla6':10}
    per_test = per_test[data_name]
    device = 'cuda:3'
    log = LOG(args)

    # prepare data
    print('loading train')
    train_data = TrainData(args, mode='train')
    print('loading valid')
    valid_data = get_DataLoader(args, mode='valid')
    print('loading test')
    test_data = get_DataLoader(args, mode='test')

    test_data.dataset.construct_should_be_remove_for_test(train_data,valid_data,test_data)
    valid_data.dataset.construct_should_be_remove_for_test(train_data,valid_data,test_data)


    args.n_user = max([train_data.users[-1] +2, valid_data.dataset.users[-1] +2, test_data.dataset.users[-1]+2])
    args.n_item = max([train_data.items[-1] +2, valid_data.dataset.items[-1] +2, test_data.dataset.items[-1]+2])
    print("total user:", args.n_user)
    print("total items:",args.n_item)
    R_sp, I_sp = get_matrix(train_data, args.n_user, args.n_item) # R交互矩阵；I共同出现；D条件概率矩阵# 先这么看；(I_sp是物品之间的相似度矩阵)
    constrastive_index, constrastive_prob = to_sample_graph(I_sp) #index代表物品与哪个物品有交互的索引号、prob代表相似度大小
   #print(constrastive_index.shape)

    # model 初始化
    model = Contrastive(args,R_sp)
    model = model.to(device)
    model.set_device(device)
    if args.model_type not in ['Contrastive']:
        model.set_sampler(args, device=device)

    #loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr = args.learning_rate)#, weight_decay=args.weight_decay)

    trials = 0

    print('training begin')
    sys.stdout.flush()

    start_time = time.time()
    #model.loss_fct = loss_fn
#     try:
    total_loss, total_loss_1, total_loss_2, total_loss_3, total_loss_4, total_loss_5  = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    iter = 0
    best_metric = 0 # 最佳指标值，在这里是最佳recall值
    #scheduler.step()
    #(users, targets, items:last K items, mask？, times)
    for iter in tqdm(range(args.max_iter)):
        for train_data_batch in train_data.generate_batch(1024):
            users, targets, items, mask, times = train_data_batch # 用户ID、targets、历史交互物品、mask
            model.train()
            optimizer.zero_grad()
            pos_items = to_tensor(targets, device)

            items_candidate = torch.tensor(constrastive_index[targets]).to(device)
            constrastive_item_prob = torch.tensor(constrastive_prob[targets]+10e-10).to(device)
            select_index = torch.multinomial(constrastive_item_prob, 1, replacement=True).squeeze() #选择与targets相似度较高的物品作为对比样本(获得索引)
            constrastive_items = items_candidate[torch.arange(items_candidate.size(0)),select_index].long() #获取选定的对比样本
            constrastive_mask = (constrastive_items != 0).bool()
            batch_times = to_tensor(times, device)


            interests, atten, readout, selection, user_eb = None, None, None, None, None

            if args.model_type in ['GRU4Rec','Contrastive', 'DNN']:
                readout, scores,item_embeddings,capsule_weight, user_eb = model(to_tensor(items, device), pos_items, to_tensor(mask, device), device, times=batch_times)
            neg_items = to_tensor(np.random.randint(0,args.n_item,[len(pos_items),args.neg_sample]), device)
            loss = model.calculate_sampled_loss(readout, pos_items, neg_items, item_embeddings)
            if args.mode == 'MIR-BFR':
                loss_re4 = model.calculate_re4(to_tensor(items, device), to_tensor(mask, device), device)
                loss = loss + args.contrastive_ratio * loss_re4

            if args.mode == 'DMIAFRec':

                # 对应3.1 解耦多兴趣模块 近似优化交叉熵损失，实现对多兴趣的解耦学习;利用对比学习 InfoNCE 优化项目划分。
                loss_constrastive = []
                for i in range(1):
                    neg_items_constrastive = to_tensor(np.random.randint(0, args.n_item, [len(pos_items), 100]), device)

                    pos_items_mask = pos_items[constrastive_mask]
                    constrastive_items_mask = constrastive_items[constrastive_mask]
                    neg_items_constrastive_mask = neg_items_constrastive[constrastive_mask]

                    try:
                        loss_value = model.calculate_contrastive_loss(pos_items_mask, constrastive_items_mask,
                                                                      neg_items_constrastive_mask, item_embeddings)
                        loss_constrastive.append(loss_value)
                    except Exception as e:
                        print(f"Error in calculating contrastive loss: {e}")
                        pdb.set_trace()  # Add this to step through the error if needed

                # Before using torch.stack, check if the list is non-empty
                if len(loss_constrastive) > 0:
                    loss_constrastive = torch.sum(torch.stack(loss_constrastive))
                else:
                    print("Warning: loss_constrastive list is empty!")
                    loss_constrastive = torch.tensor(0.0, device=device)

                #对应 3.3 多任务训练策略
                loss = loss + args.contrastive_ratio * loss_constrastive + args.ra_loss * model.calculate_atten_loss(capsule_weight)

            if args.mode == 'MIR-RV':
                loss = loss + args.contrastive_ratio * model.calculate_atten_loss(capsule_weight)


            loss.backward()
            optimizer.step()
            torch.cuda.empty_cache()  # 可选择在每个批次后调用 empty_cache()


        if iter%per_test == 0:
            print(iter)
            model.eval()
            metrics = evaluate(model, valid_data, args.hidden_size, device, args.topN, args=args)
            log_str = 'iter: %d, train loss: %.4f' % (iter, loss) # 打印loss
            if metrics != {}:
                log_str += ', ' + ', '.join(['valid ' + key +  ': %.6f' % value for key, value in metrics.items()])
            print(log_str)
            log.write_str(log_str)
            # 保存recall最佳的模型
            if 'recall' in metrics:
                recall = metrics['recall']
                if recall > best_metric:
                    best_metric = recall
                    save_model(model, log.best_model_path)
                    trials = 0
                else:
                    trials += 1
                    args.patience = 5 if args.dataset =='rocket' else 3
                    if trials > args.patience: # early stopping
                        print("early stopping!")
                        break

            # 每次test之后loss_sum置零
            total_loss = 0.0
            test_time = time.time()
            print("time interval: %.4f min" % ((test_time-start_time)/60.0))
            sys.stdout.flush()

        if iter >= args.max_iter * 1000: # 超过最大迭代次数，退出训练
            break

    load_model(model, log.best_model_path)
    model.eval()

    # 训练结束后用valid_data测试一次
    metrics = evaluate(model, valid_data, args.hidden_size, device, args.topN, args=args)
    print(', '.join(['Valid ' + key + ': %.6f' % value for key, value in metrics.items()]))
    # 训练结束后用test_data测试一次
    print("Test result:")
    metrics = evaluate(model, test_data, args.hidden_size, device, 20, args=args)
    for key, value in metrics.items():
        output = 'test ' + key + '@20' + '=%.6f' % value
        print(output)
        log.write_str(output)

    metrics = evaluate(model, test_data, args.hidden_size, device, 50, args=args)
    for key, value in metrics.items():
        output = 'test ' + key + '@50' + '=%.6f' % value
        print(output)
        log.write_str(output)

    exp_name = "%s+%s" % (args.dataset, args.model_type)

    output_dir = "output"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)  # 创建 output 目录
    item_embs = model.output_items()  # 获取物品嵌入

    np.save('output/' + exp_name + '_emb.npy', item_embs.cpu().detach().numpy())  # 保存物品嵌入
    np.save('output/' + exp_name + '_final_user_interests.npy', user_eb.cpu().detach().numpy())

if __name__ == "__main__":
    #parser = get_parser()
    #args = parser.parse_args()
    #sys.argv = ['script_name', '--data_name=rocket', '--mode=contrastive', '--contrastive_ratio=0.1', '--n_facets=6', '--ra_loss=0.1']
    args = get_arguments()


    main_process(data_name=args['data_name'],mode = args['mode'],contrastive_ratio = args['contrastive_ratio'],n_facets=args['n_facets'],ra_loss=args['ra_loss'],time_decay=args['time_decay'])
