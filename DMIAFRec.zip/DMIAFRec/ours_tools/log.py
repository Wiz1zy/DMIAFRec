import time
import pickle
import os
class LOG(object):
    def __init__(self,args):
        self.args = args
        self.time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        self.log_path = './log/%s+%s+%s+%s+%s.txt'%(self.args.dataset,self.args.model_type,self.time,args.neg_sample,args.contrastive_ratio)

        log_dir = os.path.dirname(self.log_path)  # 获取日志路径中的目录部分
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)  # 如果目录不存在，则创建该目录

        self.saved_path = './saved/%s+%s+%s.txt'%(self.args.dataset,self.args.model_type,self.time)
        exp_name = "%s+%s+%s"%(self.args.dataset,self.args.model_type,self.time)
        self.best_model_path = "./best_model/" + exp_name  # 模型保存路径名
        #创建log文件
        f = open(self.log_path, 'w')
        f.close()
        # 输出log文件
        Log ={'dataset:':args.dataset,'neg_sample':args.neg_sample,'contrastive_ratio':args.contrastive_ratio,'model':args.mode,'interest_num':args.interest_num}
        self.write_str(str(Log))
        
    def write_str(self,c):
        with open(self.log_path,'a') as f:
            f.write(c+'\n')    
#     def write_dict(self,c):
#         with open(self.log_path,'a') as f:
#             for key in c:
#                 f.write(c[key]+'\n')
    def model_save(self,obj):
        f = open(self.saved_path, 'wb')
        pickle.dump(obj, f)
        f.close()
    def model_load(self):
        f = open(self.saved_path, 'rb')
        bm25Model = pickle.load(f)
        f.close()
        return bm25Mod
