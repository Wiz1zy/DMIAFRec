import argparse
import os
import random
import shutil
import numpy as np
import torch
from sklearn.utils import shuffle
import copy
from torch.utils.data import DataLoader
# from DNN import DNN
# from Pop import Pop
#from GRU4Rec import GRU4Rec
# from MIND import MIND
# from ComiRec import ComiRec_DR, ComiRec_SA
# from REMI import REMI


def get_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', type=str, default='train', help='train | test') # train or test or output
    parser.add_argument('--dataset', type=str, default='rocket', help='book | taobao|rocket|gowalla') # 数据集
    parser.add_argument('--random_seed', type=int, default=2021)
    parser.add_argument('--hidden_size', type=int, default=64) # 隐藏层维度、嵌入维度
    parser.add_argument('--interest_num', type=int, default=4) # 兴趣的数量
    parser.add_argument('--model_type', type=str, default='Contrastive', help='DNN | GRU4Rec | MIND |our_model ..') # 模型类型
    parser.add_argument('--learning_rate', type=float, default=0.001, help='learning_rate') # 学习率
    parser.add_argument('--lr_dc', type=float, default=0.1, help='learning rate decay rate')
    parser.add_argument('--lr_dc_step', type=int, default=30, help='(k), the number of steps after which the learning rate decay')
    parser.add_argument('--max_iter', type=int, default=1000, help='(k)') # 最大迭代次数，单位是k（1000）
    parser.add_argument('--patience', type=int, default=5) # patience，用于early stopping
    parser.add_argument('--topN', type=int, default=50) # default=50
    parser.add_argument('--gpu', type=str, default=0) # None -> cpu
    parser.add_argument('--coef', default=None) # 多样性，用于test
    parser.add_argument('--exp', default='e1')
    parser.add_argument('--add_pos', type=int, default=1)
    parser.add_argument('--dropout', type=float, default=0.2)
    parser.add_argument('--layers', type=int, default=1)
    parser.add_argument('--weight_decay', type=float, default=0)
    parser.add_argument('--sampled_n', type=int, default=1280)
    parser.add_argument('--sampled_loss', type=str, default='sampled')
    parser.add_argument('--sample_prob', type=int, default=0)
    parser.add_argument('--neg_sample', type=int, default=1)
    parser.add_argument('--contrastive_ratio', type=float, default=0.01)
    parser.add_argument('--hgcn', type=bool, default=True)
    parser.add_argument('--mode', type=str, default='DisMIR')
        
    # For REMI
    parser.add_argument('--rbeta', type=float, default=0)
    parser.add_argument('--rlambda', type=float, default=0)


    return parser.parse_args(args=[])


def para_data(args):
        if args.dataset == 'book':
            path = './data/book_data/'
            batch_size = 512
            seq_len = 20
            test_iter = 1000
        if args.dataset == 'bookv':
            path = './data/bookv_data/'
            batch_size = 128
            seq_len = 20
            test_iter = 1000
        # behaviors:  27158711
        if args.dataset == 'bookr':
            path = './data/bookr_data/'
            batch_size = 128
            seq_len = 20
            test_iter = 1000
        # behaviors:  28723363
        if args.dataset == 'gowalla':
            path = './data/gowalla_data/'
            batch_size = 256
            seq_len = 20
            test_iter = 1000
        if args.dataset == 'gowalla10':
            path = './data/gowalla10_data/'
            batch_size = 1024
            seq_len = 10
            test_iter = 1000
            # behaviors:  2061264
        elif args.dataset == 'familyTV':
            path = './data/familyTV_data/'
            batch_size = 256
            seq_len = 30
            test_iter = 1000
        elif args.dataset == 'kindle':
            path = './data/kindle_data/'
            batch_size = 128
            seq_len = 20
            test_iter = 200
        elif args.dataset == 'taobao':
            batch_size = 256
            seq_len = 50
            test_iter = 500
            path = './data/taobao_data/'
            item_count = 1708531
        elif args.dataset == 'cloth':
            batch_size = 256
            seq_len = 20
            test_iter = 200
            path = './data/cloth_data/'
        elif args.dataset == 'tmall':
            batch_size = 256
            seq_len = 100
            test_iter = 200
            path = './data/tmall_data/'
        elif args.dataset == 'rocket':
            batch_size = 2048
            seq_len = 5
            test_iter = 200
            path = './data/rocket_data/'
        elif args.dataset == 'ml1m':
            batch_size = 2048
            seq_len = 5
            test_iter = 200
            path = './data/ml1m_data/'
        return batch_size,seq_len,test_iter,path

class DataIterator(torch.utils.data.IterableDataset):

    def __init__(self, args,mode):

        batch_size,seq_len,test_iter,path = para_data(args)
        self.test_iter = test_iter
        self.path = path#'./data/rocket_data/'
        
        if mode =='train':
            source = path + args.dataset + '_train.txt'
            self.train_flag = 1 # train_flag=1表示训练
        if mode == 'valid':
            source = path + args.dataset + '_valid.txt'
            self.train_flag = 0 # train_flag=1表示训练
        if mode == 'test':
            source = path + args.dataset + '_test.txt'
            self.train_flag = 0 # train_flag=1表示训练


        #print("Using time span", time_span)
        self.read(source) # 读取数据，获取用户列表和对应的按时间戳排序的物品序列，每个用户对应一个物品list
        self.users = list(self.users) # 用户列表

        #self.time_span = time_span
        self.batch_size = batch_size # 用于训练
        self.eval_batch_size = batch_size # 用于验证、测试
        self.seq_len = seq_len # 历史物品序列的最大长度
        self.index = 0 # 验证和测试时选择用户的位置的标记


    def __iter__(self):
        return self
    
    # def next(self):
    #     return self.__next__()

    def read(self, source):
        self.graph = {} # key:user_id，value:一个list，放着该user_id所有(item_id,time_stamp)元组，排序后value只保留item_id
        self.time_graph = {}
        self.users = set()
        self.items = set()
        self.times = set()
        with open(source, 'r') as f:
            for line in f:
                conts = line.strip().split(',')
                user_id = int(conts[0])
                item_id = int(conts[1])
                if len(conts) == 3:
                    time_stamp = int(conts[2])
                else:
                    idx = int(conts[2])
                    time_stamp = int(conts[3])
                self.users.add(user_id)
                self.items.add(item_id)
                self.times.add(time_stamp)
                if user_id not in self.graph:
                    self.graph[user_id] = []
                self.graph[user_id].append((item_id, time_stamp))
        for user_id, value in self.graph.items(): # 每个user的物品序列按时间戳排序
            value.sort(key=lambda x: x[1])#我觉得value大概是个list
            time_list = list(map(lambda x: x[1], value))
            time_min = min(time_list)
            # self.graph[user_id] = list(map(lambda x: [x[0], ], items))
            self.graph[user_id] = [x[0] for x in value] # 排序后只保留了item_id
            self.time_graph[user_id] = [int(round((x[1] - time_min) / 86400.0) + 1) for x in value] # 排序后只保留了item_id
        self.users = list(self.users) # 用户列表
        self.items = list(self.items) # 物品列表
    def construct_should_be_remove_for_test(self,train,valid_data,test_data):

        # 由于特殊的划分方法，不得不进行前向去重，即购买过的不要再出现了；
        self.remove_for_test = copy.deepcopy(train.graph)
        for data in [valid_data,test_data]:
            graph_c = data.dataset.graph
            for u in graph_c:
                items = graph_c[u][:int(len(graph_c[u])*0.8)]
                if u in self.remove_for_test:
                    self.remove_for_test[u].extend(items)
                else:
                    self.remove_for_test[u] = items

        
        self.remove_for_test = {user: set(self.remove_for_test[user]) for user in self.remove_for_test}

    def compute_time_matrix(self, time_seq, item_num):
        time_matrix = np.zeros([self.seq_len, self.seq_len], dtype=np.int32)
        for i in range(item_num):
            for j in range(item_num):
                span = abs(time_seq[i] - time_seq[j])
                if span > self.time_span:
                    time_matrix[i][j] = self.time_span
                else:
                    time_matrix[i][j] = span
        return time_matrix.tolist()

    def compute_adj_matrix(self, mask_seq, item_num):
        
        node_num = len(mask_seq)

        adj_matrix = np.zeros([node_num, node_num + 2], dtype=np.int32)

        adj_matrix[0][0] = 1
        adj_matrix[0][1] = 1
        adj_matrix[0][-1] = 1

        adj_matrix[item_num - 1][item_num - 1] = 1
        adj_matrix[item_num - 1][item_num] = 1
        adj_matrix[item_num - 1][-1] = 1

        for i in range(1, item_num - 1):
            adj_matrix[i][i] = 1
            adj_matrix[i][i + 1] = 1
            adj_matrix[i][-1] = 1

        if (item_num < node_num):
            for i in range(item_num, node_num):
                adj_matrix[i][0] = 1
                adj_matrix[i][1] = 1
                adj_matrix[i][-1] = 1

        return adj_matrix.tolist()

    def __next__(self):
        if self.train_flag == 1: # 训练
            user_id_list = random.sample(self.users, self.batch_size) # 随机抽取batch_size个user
        else: # 验证、测试，按顺序选取eval_batch_size个user，直到遍历完所有user
            total_user = len(self.users)
            if self.index >= total_user:
                self.index = 0
                raise StopIteration
            user_id_list = self.users[self.index: self.index+self.eval_batch_size]
            self.index += self.eval_batch_size

        item_id_list = []##target_items
        hist_time_list = []#time list没啥用；
        hist_item_list = []#最近几个items;
        time_matrix_list = []
        hist_mask_list = []
        adj_matrix_list = []
        for user_id in user_id_list:
            item_list = self.graph[user_id] # 排序后的user的item序列
            time_list = self.time_graph[user_id] # 排序后的user的times序列
            # 这里训练和（验证、测试）采取了不同的数据选取方式
            if self.train_flag == 1: # 训练，选取训练时的label
                k = random.choice(range(4, len(item_list))) # 从[4,len(item_list))中随机选择一个index
                item_id_list.append(item_list[k]) # 该index对应的item加入item_id_list
            else: # 验证、测试，选取该user后20%的item用于验证、测试
                k = int(len(item_list) * 0.8)#这里测试集合选取不受seq_len的影响；
                item_id_list.append(item_list[k:])
            # k前的item序列为历史item序列
            if k >= self.seq_len: # 选取seq_len个物品
                hist_item_list.append(item_list[k-self.seq_len: k])
                hist_mask_list.append([1.0] * self.seq_len)
                hist_time_list.append(time_list[k - self.seq_len: k])  # ★ 新增：同步截取时间
                #time_matrix_list.append(self.compute_time_matrix(time_list[k - self.seq_len: k], self.seq_len))
                #adj_matrix_list.append(self.compute_adj_matrix([1.0] * self.seq_len, self.seq_len))

            else:
                hist_item_list.append(item_list[:k] + [0] * (self.seq_len - k))
                hist_mask_list.append([1.0] * k + [0.0] * (self.seq_len - k))
                hist_time_list.append(time_list[:k] + [0] * (self.seq_len - k))  # ★ 新增：同步截取时间并补零
                #time_matrix_list.append(self.compute_time_matrix(time_list[:k] + [0] * (self.seq_len - k), k)) #这个好像是ij之间的时间差
               # adj_matrix_list.append(self.compute_adj_matrix([1.0] * k + [0.0] * (self.seq_len - k), k))# 不知道是干啥的？

        # 返回用户列表（batch_size）、物品列表（label）（batch_size）、
        # 历史物品列表（batch_size，seq_len）、历史物品的mask列表（batch_size，seq_len）
        #return user_id_list, item_id_list, hist_item_list, hist_mask_list#, (time_matrix_list, adj_matrix_list)
        return user_id_list, item_id_list, hist_item_list, hist_mask_list, hist_time_list

class TrainData(object):
    def __init__(self, args,mode):
        batch_size,seq_len,test_iter,path = para_data(args)
        self.test_iter = test_iter
        self.path = path#'./data/rocket_data/'
        
        source = path + args.dataset + '_train.txt'

        #print("Using time span", time_span)
        self.read(source) # 读取数据，获取用户列表和对应的按时间戳排序的物品序列，每个用户对应一个物品list
        self.users = list(self.users) # 用户列表

        #self.time_span = time_span
        self.batch_size = batch_size # 用于训练
        self.eval_batch_size = batch_size # 用于验证、测试
        self.seq_len = seq_len # 历史物品序列的最大长度
        self.index = 0 # 验证和测试时选择用户的位置的标记
        self.user_id_list, self.item_id_list, self.hist_item_list,self.hist_mask_list = self.all_samples()
        #print("total user:", len(self.users))
        #print("total items:", len(self.items))
        
    def add_valid_test_partial_train(self,valid_data,test_data):
        for data in [valid_data,test_data]:
            graph_c = data.dataset.graph
            for u in graph_c:
                items = graph_c[u][:int(len(graph_c[u])*0.8)]
                if u in self.graph:
                    self.graph.extend(items)
                else:
                    self.graph[u] = items
        self.users = list(self.graph.keys())
        self.user_id_list, self.item_id_list, self.hist_item_list,self.hist_mask_list = self.all_samples()

    def __iter__(self):
        return self
    
    # def next(self):
    #     return self.__next__()

    def read(self, source):
        self.graph = {} # key:user_id，value:一个list，放着该user_id所有(item_id,time_stamp)元组，排序后value只保留item_id
        self.time_graph = {}
        self.users = set()
        self.items = set()
        self.times = set()
        with open(source, 'r') as f:
            for line in f:
                conts = line.strip().split(',')
                user_id = int(conts[0])
                item_id = int(conts[1])
                if len(conts) == 3:
                    time_stamp = int(conts[2])
                else:
                    idx = int(conts[2])
                    time_stamp = int(conts[3])
                self.users.add(user_id)
                self.items.add(item_id)
                self.times.add(time_stamp)
                if user_id not in self.graph:
                    self.graph[user_id] = []
                self.graph[user_id].append((item_id, time_stamp))
        for user_id, value in self.graph.items(): # 每个user的物品序列按时间戳排序
            value.sort(key=lambda x: x[1])#我觉得value大概是个list
            time_list = list(map(lambda x: x[1], value))
            time_min = min(time_list)
            # self.graph[user_id] = list(map(lambda x: [x[0], ], items))
            self.graph[user_id] = [x[0] for x in value] # 排序后只保留了item_id
            self.time_graph[user_id] = [int(round((x[1] - time_min) / 86400.0) + 1) for x in value] # 排序后只保留了item_id
        self.users = list(self.users) # 用户列表
        self.items = list(self.items) # 物品列表


    def all_samples(self):
        user_id_list =  [] 
       
        item_id_list = []##target_items
        hist_item_list = []#最近几个items;
        hist_mask_list = [] #masks
        hist_time_list = []
        for user_id in self.users:
            item_list = self.graph[user_id] # 排序后的user的item序列
            time_list = self.time_graph[user_id]
            # 这里训练和（验证、测试）采取了不同的数据选取方式
            for k in range(4, len(item_list)):
                user_id_list.append(user_id)
                item_id_list.append(item_list[k]) # 该index对应的item加入item_id_list
                if k >= self.seq_len: # 选取seq_len个物品
                    hist_item_list.append(item_list[k-self.seq_len: k])
                    hist_mask_list.append([1.0] * self.seq_len)
                    hist_time_list.append(time_list[k - self.seq_len: k])
                else:
                    hist_item_list.append(item_list[:k] + [0] * (self.seq_len - k))
                    hist_mask_list.append([1.0] * k + [0.0] * (self.seq_len - k))
                    hist_time_list.append(time_list[:k] + [0] * (self.seq_len - k))

        # 返回用户列表（batch_size）、物品列表（label）（batch_size）、
        # 历史物品列表（batch_size，seq_len）、历史物品的mask列表（batch_size，seq_len）
        user_id_list = np.array(user_id_list)
        item_id_list = np.array(item_id_list)
        hist_item_list = np.array(hist_item_list)
        hist_mask_list = np.array(hist_mask_list)
        # return user_id_list, item_id_list, hist_item_list, hist_mask_list#, (time_matrix_list, adj_matrix_list)
        return user_id_list, item_id_list, hist_item_list, hist_mask_list, hist_time_list
    def generate_batch(self,batch=2048):
        #一比一采样
        index = np.arange(len(self.user_id_list))
        index = shuffle(index)
        batch_data = []
        for i in range(int(len(index)/batch)):
            random_index = index[i*batch:(i+1)*batch]
            batch_data.append([self.user_id_list[random_index],self.item_id_list[random_index], self.hist_item_list[random_index],self.hist_mask_list[random_index],self.hist_time_list[random_index]])
        return batch_data
                

def get_DataLoader(args, mode):
    dataIterator = DataIterator(args, mode)
    return DataLoader(dataIterator, batch_size=None, batch_sampler=None)


def setup_seed(seed):
     torch.manual_seed(seed)
     torch.cuda.manual_seed_all(seed)
     np.random.seed(seed)
     random.seed(seed)
     torch.backends.cudnn.deterministic = True


# 获取模型
def get_model(dataset, model_type, item_count, batch_size, hidden_size, interest_num, seq_len, routing_times=3, args=None, device=None):
# def get_model(dataset, model_type, item_count, batch_size, hidden_size, interest_num, seq_len, beta, routing_times=3,):
    add_pos = True
    if args:
        add_pos = args.add_pos == 1
    else:
        print ("Invalid model_type : %s", model_type)
        return



# 生成实验名称
def get_exp_name(dataset, model_type, batch_size, lr, hidden_size, seq_len, interest_num, topN, save=True, exp='e1'):
    extr_name = exp
    para_name = '_'.join([dataset, model_type, 'b'+str(batch_size), 'lr'+str(lr), 'd'+str(hidden_size), 
                            'len'+str(seq_len), 'in'+str(interest_num), 'top'+str(topN)])
    exp_name = para_name + '_' + extr_name

    while os.path.exists('best_model/' + exp_name) and save:
        # flag = input('The exp name already exists. Do you want to cover? (y/n)')
        # if flag == 'y' or flag == 'Y':
        shutil.rmtree('best_model/' + exp_name)
        break
        # else:
        #     extr_name = input('Please input the experiment name: ')
        #     exp_name = para_name + '_' + extr_name

    return exp_name


def save_model(model, Path):
    torch.save(model.state_dict(), Path + '.pt')


def load_model(model, path):
    model.load_state_dict(torch.load(path + '.pt'))
    print('model loaded from %s' % path)


def to_tensor(var, device):
    var = torch.Tensor(var)
    var = var.to(device)
    return var.long()


# 读取物品类别信息，返回一个dict，key:item_id，value:cate_id
def load_item_cate(source):
    item_cate = {}
    with open(source, 'r') as f:
        for line in f:
            conts = line.strip().split(',')
            item_id = int(conts[0])
            cate_id = int(conts[1])
            item_cate[item_id] = cate_id
    return item_cate


# 计算物品多样性，item_list中的所有item两两计算
def compute_diversity(item_list, item_cate_map):
    n = len(item_list)
    diversity = 0.0
    for i in range(n):
        for j in range(i+1, n):
            diversity += item_cate_map[item_list[i]] != item_cate_map[item_list[j]]
    diversity /= ((n-1) * n / 2)
    return diversity
